from flask import Flask
DATABASE = 'dojos_and_ninjas_schema'
app = Flask(__name__)
app.secret_key = "10a34980-7359-4624-82e9-cc4f8b9ab963"
